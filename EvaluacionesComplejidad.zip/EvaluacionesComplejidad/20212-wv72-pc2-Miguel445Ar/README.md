# Complejidad Algorítmica

###### Segunda Práctica Calificada - 2021-02

# Instrucciones

* Resuelva usando notebooks o archivos de código python estándar.
* Errores de compilación automáticamente equivale a 0 puntos en la pregunta correspondiente.
* Soluciones supuestas o sospechosas anulan la pregunta y le otorgan 0 puntos en la pregunta correspondiente.
* Para la pregunta 1, debe proporcionar sus propios casos de prueba, caso contrario perderá 30% del puntaje correspondiente.

## Pregunta 1

Un vendedor da el cambio con monedas con ciertas  denominaciones en soles, por ejemplo:

`Denominación=[1, 2, 5, 10, 20]`, sin embargo las monedas vienen bañadas de cierta cantidad de oro en kilates, por ejemplo:

* Las monedas de 1 sol traen 18 k
* Las monedas de 2 soles traen 16 k
* Las monedas de 5 soles traen 20 k
* Las monedas de 10 soles traen 17 k
* Las monedas de 20 soles traen 15 k

Para cierta cantidad de vuelto V

1. (5 puntos) Cuál sería la combinación de monedas que le conviene recibir al comprador.

2. (5 puntos) Cuál sería la combinación de monedas que le conviene dar al vendedor.

## Pregunta 2 (10 puntos)

El imperio intergaláctico tiene `n` portales y `m` rutas bidireccionales a través de los portales. Cada ruta tiene una capacidad
establecida medida en naves espaciales por segundo. Existe un camino desde cada portal a cada otro portal siguiendo cierta secuencia de caminos. El departamento intergaláctico de mantenimiento del continuo espacio tiempo está saturado de trabajo
y necesita cerrar la mayor cantidad de rutas posibles sin desconectar los portales. Ellos quieren hacerlo de tal manera que la capacidad mínima entre todos los caminos sea lo más grande posible.

### Input

La primera línea del input tiene el numero de casos, `N` y siguen `N` casos. Cada caso empieza con una línea que contiene `n` entre 1 y 100 y `m` entre 1 y 10000. Las siguientes `m` lineas describen las `m` rutas. cada una con 3 enteros `u`, `v` y `c`, (`u` y `v` entre 0 y `n` - 1 y c entre 1 y 1000). `u` y `v` son los extremos de cada camino y `c` es su capacidad.

#### Ejemplo

```
2
2 3
0 1 10
0 1 20
0 0 30
4 5
0 1 1
3 1 2
1 2 3
2 3 4
0 2 5
```

### Ouput

Por cada caso, el output debe contener una linea con `Caso #x:` seguido de la capacidad mínima de los caminos restantes.

#### Ejemplo

```
Caso #1: 20
Caso #2: 3
```


