# Pregunta 1

El regimen de una pequeña dictadura ha sido derrocado por una rebelión inesperada. Debido a los enormes disturbios causados a la economía mundial,
un poderoso Imperio militar ha decidido invadir el país y reinstalar el régimen anterior.

Para el éxito de la operación, la comunicación entre la capital y la ciudad más larga debe ser cortada. Esta es una tarea dificil dado que las ciudades
en el país están conectadas por una red de computadoras usando el Protocolo de Internet, el cual permite que los mensajes tomen cualquier ruta a través
de la red. Debido a esto, la red debe ser completamente separada en 2 partes, con la capital en una de las partes y la ciudad más grande en otra y sin
conexiones entre ellas.

Hay una gran diferencia entre el costo de sabotear diferentes conexiones, dado que algunas son más sencillas que otras.

Escriba un programa que dada la especificación de la red y el costo de sabotear cada conexión, determine cuales conexiones cortar para poder separar
la capital de la ciudad más grande con el menor costo posible.

## Input

El archivo de entrada contiene varios conjuntos de líneas.

La primera línea de cada conjunto tiene 2 enteros, separados por un espacio: El primer número de ciudades, `N` en la red, el cual contiene como mucho 50.
La segunda es el total de conexiones `M`, máximo 500.

Las siguientes M líneas especifican las conexiones. Cada línea tiene 3 partes separadas por espacios: La primeras 2 son las ciudades unidas por la conexión
y luego el costo de cortar la conexión.

El input termina con un caso donde N y M son ceros.

### Ejemplo

```
5 8
1 4 30
1 3 70
5 3 20
4 3 5
4 5 15
5 2 10
3 2 25
2 4 50
5 8
1 4 30
1 3 70
5 3 20
4 3 5
4 5 15
5 2 10
3 2 25
2 4 50
0 0
```

## Output

Por cada input, se debe producir varias lineas, El output de cada conjunto debe ser un par de ciudades entre las cuales la conexión
se debe cortar, cada par en una línea con números separados por un espacio. Si hay más de una solución, puede usar cualquiera. Una línea
en blanco entre cada set.

### Ejemplo

```
4 1
3 4
3 5
3 2
4 1
3 4
3 5
3 2

```

# Importante

Debe proporcionar una explicación de las razones por las que utiliza el algoritmo y las modificaciones o adiciones que realice, caso contrario
solo se considera máxmo el 50% del puntaje.
