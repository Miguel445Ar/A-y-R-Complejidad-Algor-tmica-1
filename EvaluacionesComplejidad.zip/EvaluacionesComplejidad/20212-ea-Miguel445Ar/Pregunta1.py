import math 
import heapq as hq

class DisjointSet:
  # todos los métodos tiene el parametro oculto self
  # self === this
  # Constructor!
  def __init__(self, n):
    self.S = [-1]*n

  ## Acuerdo de personas honorables: __algo: privado, _algo: protegido, algo: publico.
  def find(self, x):
    if self.S[x] < 0:
      return x
    p = self.find(self.S[x])
    self.S[x] = p
    return p

  def union(self, x, y):
    Xr = self.find(x)
    Yr = self.find(y)
    if Xr != Yr:
      if self.S[Xr] < self.S[Yr]:
        self.S[Xr] += self.S[Yr]
        self.S[Yr] = Xr
      else:
        self.S[Yr] += self.S[Xr]
        self.S[Xr] = Yr

  def isSameSet(self, x, y):
    return self.find(x) == self.find(y)

def dijkstra(G, s):
  n = len(G)
  cost = [float('inf')]*n
  cost[s] = 0
  path = [-1]*n
  visited = [False]*n

  queue = [(0, s)]

  while queue:
    c, u = hq.heappop(queue)
    if visited[u]: continue
    visited[u] = True
    for v, w in G[u]:
      if not visited[v] and c + w < cost[v]:
        cost[v] = c + w
        path[v] = u
        hq.heappush(queue, (cost[v], v))
  return path
def kruskalMod(G,s,e):
  n = len(G)
  for v,w in G[s]:
      if v == e:
          G[s].remove((v,w))
  for v,w in G[e]:
      if v == s:
          G[e].remove((v,w))
  edges = []
  for u in range(n):
    for v, w in G[u]:
        hq.heappush(edges, (w, u, v))
  uf = DisjointSet(n)

  echilds = [v for v, w in G[e]]
  schilds = [v for v, w in G[s]]

  T = []
  while True:
      path = dijkstra(G,s)
      if path[e] == -1:
          break
      w, u , v = hq.heappop(edges)
      band = False
      for s in schilds:
          if (u == s) and len(schilds) == 1:
              band = True
      for e in echilds:
          if (u == e) and len(schilds) == 1:
              band = True
      if band:
          continue
      T.append((w,u,v))
  return T


def readInput():
    with open("input.txt") as file:
        n, m = map(int,file.readline().split())
        graph = [[] for _ in range(n)]
        for i in range(m):
            v, u, w = map(int,file.readline().strip().split())
            graph[v-1].append((u-1,w))
            graph[u-1].append((v-1,w))
        T = kruskalMod(graph,2,4)
        print(T)
        
readInput()