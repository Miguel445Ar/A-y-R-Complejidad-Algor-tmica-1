# Programas WHILE

Considere que existen la siguientes construcciones básicas:

```
x = 0
x = x + 1
x = x - 1
```


Y las siguientes construcciones secundarias

```
x = c
x = x + y
x = x - y
x = x * y
```

Además, las siguientes operaciones lógicas que producen 0 en caso la expresión sea Falsa

```
x = c AND d
x = c OR d
x = c < d
x = c > d
x = c == d
x = c >= d
x = c <= d
```

Implemente los siguientes programas WHILE

* (2 puntos) División entera

* (2 puntos) Residuo de división entera

* (2 puntos) Potencia

