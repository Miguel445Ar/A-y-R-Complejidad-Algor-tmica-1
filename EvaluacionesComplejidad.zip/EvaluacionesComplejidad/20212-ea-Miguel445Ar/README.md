# Complejidad Algorítmica

###### Examen Parcial 2021-02

## Instrucciones

* Lea las instrucciones de cada pregunta detenidamente.

* Las preguntas de programación requiere que su respuesta lea los datos de entrada
  de una manera precisa y producir un resultado preciso también.

* Debe desarrollar el examen usando python, y copiar sus respuestas a los archivos
  indicados.
  
* Las preguntas de programas WHILE las puede resolver en archivos de texto, sea ordenado

* Las preguntas sobre máquinas de Turing, deben ser enviadas como una imágen y
  proporcionando por lo menos 3 ejemplos con la correspondiente explicación de como
  va siendo ejecutado por la máquina, cambiando de estados.
  
* Para su calificación debe hacer commit a todos los archivos de sus soluciones en
	este repositorio, luego debe descargar como zip y subir a la actividad
	correspondiente en el aula virtual (imagen de referencia para descargar zip más
	abajo).
    
 ![fig 1](assets/zipping.png)

* En la duración del examen se están contemplando los 10 últimos minutos para
	adjuntar su solución. Tenga en cuenta este aspecto en caso de contar con
	dificultades de acceso a internet.

* Soluciones misteriosas o supuestas invalidan la respuesta.

* La detección de plagio parcial o totalmente será penalizado con cero de nota.

* Cada examen cuenta con un equipo académico, el cual estará conectado durante
	los primeros 20 minutos del examen.

* El alumno debe dedicar los primeros 20 minutos a revisar las preguntas del
	examen y de presentarse alguna duda enviar un correo al profesor Luis Canaval
	al correo pcsilcan@upc.edu.pe.

* De no recibir respuesta del equipo académico, o tener algún inconveniente
	adicional pasado los primeros 20 minutos, puede enviar un correo al profesor
	Luis Canaval al correo pcsilcan@upc.edu.pe.

* Los profesores en mención, solo recibirán correos provenientes de las cuentas
	UPC, de ninguna manera se recibirán correos de cuentas públicas.

* Ante problemas técnicos, debe de forma obligatoria adjuntar evidencias del
	mismo, como capturas de pantalla, videos, fotos, etc. Siendo requisito
	fundamental que, en cada evidencia se pueda apreciar claramente la fecha y
	hora del sistema operativo del computador donde el alumno está rindiendo el
	examen.

* Los problemas técnicos se recibirán como máximo 15 minutos culminado el
	examen.

* Estamos seguros que cada uno realizará su examen. Sin embargo, para evitar
	cualquier perspicacia, le recomendamos leer sus reglamentos de estudios y
	disciplina del alumno, en el cual se indican las faltas y las sanciones en el
	caso de la copia de exámenes (falta contra la probidad académica).
  


##### Lima, Diciembre del 2021
