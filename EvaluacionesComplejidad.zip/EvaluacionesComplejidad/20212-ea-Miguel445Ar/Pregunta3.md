# Máquinas de Turing

Implemente las máquinas para los siguientes casos:

* (3 puntos) Multiplicación de números en base 10 de 1 o 2 dígitos.
* (3 puntos) Restar 2 números donde el primero es mayor que el segundo (ejemplo: 00000c00 -> 000)


## Importante

Recuerde que debe proporcionar 3 ejemplos con explicaciones detalladas del funcionamiento para cada caso.
