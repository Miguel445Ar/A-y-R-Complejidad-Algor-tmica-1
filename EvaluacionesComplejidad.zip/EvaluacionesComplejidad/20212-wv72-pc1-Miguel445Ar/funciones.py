# Copie aquí la respuesta a la pregunta del ordenamiento inverso.
def inverseSort(arr):
  pass