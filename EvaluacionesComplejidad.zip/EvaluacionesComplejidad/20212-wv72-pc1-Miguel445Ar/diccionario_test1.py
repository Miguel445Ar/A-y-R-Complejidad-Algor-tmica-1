import diccionario as d

def test_contarLetras1():
    assert d.contarLetras("mi mama") == {"m": 3, "a": 2, "i": 1}
