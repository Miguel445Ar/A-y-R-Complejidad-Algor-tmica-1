import segundo as s;

def test_contarLetras1():
    assert s.contarLetras("mi mama") == {"m": 3, "a": 2, "i": 1}

def test_contarLetras2():
    assert s.contarLetras("aaabbbccabc") == {"a": 4, "b": 4, "c": 3}
