import grafos as g

def test_edgeCounter2():
  G = [[0, 1, 0, 1],
       [0, 0, 1, 0],
       [1, 0, 0, 0],
       [0, 0, 1, 0]]
  assert g.edgeCounter(G) == 5
