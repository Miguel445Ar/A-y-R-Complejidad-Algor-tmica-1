import tercero as t;

def test_isNotDirected1():
  G = [[1, 2, 3],
       [0, 3],
       [0],
       [0, 1]]
  assert t.isNotDirected(G) == True

def test_isNotDirected2():
  G = [[1, 2],
       [0, 3],
       [0, 3],
       [0, 1]]
  assert t.isNotDirected(G) == False

def test_edgeCounter1():
  G = [[0, 1, 0, 1],
       [0, 0, 1, 0],
       [0, 0, 0, 0],
       [0, 0, 1, 0]]
  assert t.edgeCounter(G) == 4

def test_edgeCounter2():
  G = [[0, 1, 0, 1],
       [0, 0, 1, 0],
       [1, 0, 0, 0],
       [0, 0, 1, 0]]
  assert t.edgeCounter(G) == 5
