# Complejidad Algorítmica

###### Práctica Calificada 1 - 2021-02

## Instrucciones

* La práctica consiste resolver una serie de ejercicios y copiar tus respuestas
  en los archivos correspondientes.
* Se proporcionan "playgrounds" en forma de notebooks para que desarrolles y
  verifiques tus respuestas.
* Cuando estés satisfecho con tus respuestas, deberás copiarlas en los archivos
  indicados en las funciones correspondientes.
* Puedes agregar todas las funciones y sentencias que desees, pero las funciones
  proporcionadas deberan mantener sus nombres y parámetros.

## Rúbrica de calificación

El detalle de cada parte estará indicado en los archivos proporcionados.

* Pregunta 1 (6 puntos): Python básico.
* Pregunta 2 (6 puntos): Grafos.
* Pregunta 3 (8 puntos): Búsqueda en grafos
