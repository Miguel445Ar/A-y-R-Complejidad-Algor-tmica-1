import funciones as f;

def test_inverseSort2():
  a = "h o l a".split()
  f.inverseSort(a)
  assert a == ["o", "l", "h", "a"]
