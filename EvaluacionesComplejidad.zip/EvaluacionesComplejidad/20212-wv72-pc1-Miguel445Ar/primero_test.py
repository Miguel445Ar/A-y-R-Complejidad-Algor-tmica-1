import primero as p;

def test_inverseSort1():
  a = [1, 2, 3, 4, 5]
  p.inverseSort(a)
  assert a == [5, 4, 3, 2, 1]

def test_inverseSort2():
  a = "h o l a".split()
  p.inverseSort(a)
  assert a == ["o", "l", "h", "a"]
