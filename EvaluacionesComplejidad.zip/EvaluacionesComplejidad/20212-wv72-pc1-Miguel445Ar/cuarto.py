
# Puedes agregar todas las funciones adicionales que necesites, pero no puedes
# modificar las firmas de los de las funciones proporcionados

def numNodos(G): # No cambiar el nombre de la función ni parámetros

  return None # modificar acá para retornar el diccionario respuesta

def minMaxCost(G): # No cambiar el nombre de la función ni parámetros

  return None # modificar acá para retornar el diccionario respuesta
