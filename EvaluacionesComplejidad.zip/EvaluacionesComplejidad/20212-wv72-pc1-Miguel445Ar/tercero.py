def isNotDirected(G):
  pass

def edgeCounter(G):
  pass