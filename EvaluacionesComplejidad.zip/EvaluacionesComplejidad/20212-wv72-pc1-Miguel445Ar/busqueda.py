# Copie aquí el código de las preguntas de numNodos(G) y minMaxCost(G)

# Puedes agregar todas las funciones adicionales que necesites, pero no puedes
# modificar las firmas de los de las funciones proporcionados
import  heapq

def numNodos(G): # No cambiar el nombre de la función ni parámetros
  cont = 0
  start = 0
  def BFS(graph, start):
    parent = [0]*len(graph)
    visited = [0]*len(graph)
    visited[start] = 1
    queue = [start]

    while len(queue) > 0:
      u = queue.pop(0)
      for v in range(len(graph[u])):
        if graph[u,v] == 1 and visited[v] == 0:
          visited[v] = 1
          parent[v] = u
          queue.append(v)
    return parent;
  path = BFS(G,start)
  return path

def minMaxCost(G): # No cambiar el nombre de la función ni parámetros
  value = 0
  def ModedDijkstra(graph, start):
    n = len(graph)
    visited = [False]*n
    cost = [-1]*n
    path = [None]*n
    cost[start] = 0
    path[start] = -1
    queue = [(start,0)]
    heapq._heapify_max(queue)
    while queue:
        v,c = heapq._heappop_max(queue)
        heapq._heapify_max(queue)
        if visited[v] == False:
            visited[v] = True
            for ve,w in graph[v]:
                nc = c + w
                if not visited[ve] and nc > cost[ve]:
                    path[ve] = v
                    cost[ve] = nc
                    heapq.heappush(queue,(ve,nc))
                    heapq._heapify_max(queue)
    return path, cost

  def roadGraph(path,start,node,lista):
    if node == start:
        lista.insert(0,node)
        return
    index = path[node]
    lista.insert(0,node)
    roadGraph(path,start,index,lista)

  path, cost = ModedDijkstra(l,value)
  lista = []
  maxi = cost[0]
  index = 0
  for k in range(len(cost)):
      if cost[k] > maxi:
          index = k
          maxi = cost[k]
  roadGraph(path,value,index,lista)
  return cost[index]

