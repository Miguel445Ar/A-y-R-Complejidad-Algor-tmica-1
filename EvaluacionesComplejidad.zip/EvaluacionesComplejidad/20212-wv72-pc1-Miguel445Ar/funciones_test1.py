import funciones as f;

def test_inverseSort1():
  a = [1, 2, 3, 4, 5]
  f.inverseSort(a)
  assert a == [5, 4, 3, 2, 1]
