import busqueda as c
import math

def test_minMaxCost1():
  G = [[(2, 6), (3, 9)],
       [(0, 3), (3, 8), (5, 9)],
       [],
       [(5, 8)],
       [],
       [(6, 7), (7, 7),],
       [(4, 4)],
       [(4, 6)]]
  assert c.minMaxCost(G) == (math.inf, 6)
