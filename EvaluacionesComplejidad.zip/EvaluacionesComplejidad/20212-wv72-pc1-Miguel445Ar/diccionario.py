# Copie aquí la solución al problema del contador de letras

def contarLetras(a):
  pass