# Copie aquí las funciones completas isNotDirected(G) y edgeCounter(G)

def isNotDirected(G): # No cambiar el nombre de la función ni parámetros
  nodes = [False]*len(G)
  def isBidirectional(v):
    cont = 0
    for i in G[v]:
      for j in G[i]:
        if j == v:
          cont +=1
    if cont == len(G[v]):
      return True
    else:
      return False
  for i in range(len(G)):
    nodes[i] = isBidirectional(i)
    if nodes[i] == False:
      return False
  return True

def edgeCounter(G): # No cambiar el nombre de la función ni parámetros
  cant = 0;
  for i in range(len(G)):
    for k in range(len(G[0])):
      if G[i][k] == 1:
        cant+=1
  return cant
