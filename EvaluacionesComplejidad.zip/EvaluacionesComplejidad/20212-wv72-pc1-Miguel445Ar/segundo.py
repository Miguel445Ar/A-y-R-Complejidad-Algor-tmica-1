
def contarLetra(i,f,texto,letra):
  if i >= f:
    if texto[f] == letra:
      return 1
    else:
      return 0
  medio = (i+f)//2
  c1 = contarLetra(i,medio,texto,letra)
  c2 = contarLetra(medio+1,f,texto,letra)
  return c1 + c2

def contarLetras(a):
  dictionary = {}
  for c in a:
    if c != ' ':
      dictionary[c] = contarLetra(0,len(a)-1,a,c)
  return dictionary
