import busqueda as c

def test_numNodos():
  G = [[1, 2],
       [0, 3],
       [0],
       [0, 1]]
  assert c.numNodos(G) == 3

