import grafos as g

def test_isNotDirected2():
  G = [[1, 2],
       [0, 3],
       [0, 3],
       [0, 1]]
  assert g.isNotDirected(G) == False
