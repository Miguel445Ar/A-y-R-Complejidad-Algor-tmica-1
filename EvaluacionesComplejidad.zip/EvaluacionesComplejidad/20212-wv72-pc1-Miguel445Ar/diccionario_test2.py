import diccionario as d

def test_contarLetras2():
    assert d.contarLetras("aaabbbccabc") == {"a": 4, "b": 4, "c": 3}
